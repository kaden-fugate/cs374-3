#ifndef GLOBALS_H
#define GLOBALS_H

extern int signaledTSTP;
extern int foregroundOnly;
extern int child_pid;

#endif