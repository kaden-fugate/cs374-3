#include "globals.h"

int signaledTSTP = 0;
int foregroundOnly = 0;
int child_pid = -255;